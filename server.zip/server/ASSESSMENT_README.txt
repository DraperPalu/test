Technical Assessment from Draper Palu

Visual Studio 2022 was used for the Game Server

The code which handles server connections was taken from 
Ninja WebSockets on GitHub

The Game Logic is found in ConnectRules.cs

The server uses the WebSocket API and listens for the client on port 8081

When the Game Server Project is running, a console terminal displays logging
information.