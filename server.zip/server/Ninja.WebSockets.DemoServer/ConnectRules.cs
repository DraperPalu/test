﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;

namespace WebSockets.DemoServer
{
    public class ConnectRules
    {
        const int MAX_X = 3;
        const int MAX_Y = 3;

        // Use Stack to keep track of all traversed nodes in case
        // needed later
        static Stack<Point> connectRulesStack = new Stack<Point>();
        // Segments needed to see if any lines cross
        static List<ConnectSegment> connectSegmentsList = new List<ConnectSegment>();
        // First and Last nodes kept to check for valid start points
        static Point nodeFirst = new Point();
        static Point nodeLast = new Point();
        // Selected First and Last used for current valid drawn line
        static Point nodeSelectedFirst = new Point();
        static Point nodeSelectedLast = new Point();
        static bool isNodeOne;
        static bool isFirst;
        static string headingMsg = "";

        // Method called when there is a packet from the client to Process
        public Dictionary<string, object> ProcessConnect(Dictionary<string, object> connectDecoded, out string msg)
        {
            Dictionary<string, object> response = new Dictionary<string, object>();
            string responseMsg = "";

            // Get point info
            connectDecoded.TryGetValue("body", out object body);

            if (body != null)
            {
                Point node = new Point();
                Dictionary<string, int> point = JsonConvert.DeserializeObject<Dictionary<string, int>>(body.ToString());
                point.TryGetValue("x", out int x);
                point.TryGetValue("y", out int y);

                node.X = x;
                node.Y = y;

                // First node in game selected
                if (connectRulesStack.Count == 0)
                {
                    // First move, first and last nodes are the same
                    nodeFirst.X = node.X;
                    nodeFirst.Y = node.Y;
                    nodeLast.X = node.X;
                    nodeLast.Y = node.Y;
                    nodeSelectedFirst.X = node.X;
                    nodeSelectedFirst.Y = node.Y;
                    nodeSelectedLast.X = node.X;
                    nodeSelectedLast.Y = node.Y;

                    msg = "VALID_START_NODE";
                    responseMsg = "Select a second node to complete the line.";
                    headingMsg = TogglePlayer(false);
                    isNodeOne = true;

                    // Save first node
                    connectRulesStack.Push(node);
                }
                // Second node selected 
                else if (connectRulesStack.Count > 0)
                {
                    if (isNodeOne)
                    {
                        nodeSelectedLast.X = node.X;
                        nodeSelectedLast.Y = node.Y;

                        if (AddLine(node))
                        {
                            isNodeOne = false;

                            if (isFirst)
                            {
                                nodeFirst.X = node.X;
                                nodeFirst.Y = node.Y;
                                isFirst = false;
                            }
                            else
                            {
                                nodeLast.X = node.X;
                                nodeLast.Y = node.Y;
                            }

                            // Got new node coordinates 
                            Dictionary<string, object> newLine = new Dictionary<string, object>();
                            Dictionary<string, int> start = new Dictionary<string, int>();
                            Dictionary<string, int> end = new Dictionary<string, int>();

                            if (CheckWinner(nodeFirst) && CheckWinner(nodeLast))
                            {
                                responseMsg = TogglePlayer(true) + " Wins!!!!!";
                                msg = "GAME_OVER";
                                headingMsg = "Game Over!!!";
                            }
                            else
                            {
                                msg = "VALID_END_NODE";
                                headingMsg = TogglePlayer(true);
                                responseMsg = "Valid line. Next player's move";
                            }
                            start.Add("x", nodeSelectedFirst.X);
                            start.Add("y", nodeSelectedFirst.Y);
                            end.Add("x", nodeSelectedLast.X);
                            end.Add("y", nodeSelectedLast.Y);
                            newLine.Add("start", start);
                            newLine.Add("end", end);
                            response.Add("newLine", newLine);

                            // Add segment to List
                            connectSegmentsList.Add(new ConnectSegment(nodeSelectedFirst, nodeSelectedLast));
                        }
                        else
                        {
                            msg = "INVALID_END_NODE";
                            response.Add("newLine", null);
                            responseMsg = "Invalid move. Try Again!";
                            headingMsg = TogglePlayer(false);
                            isFirst = false;
                            isNodeOne = false;
                        }
                    }
                    else
                    {
                        // Node one must start on first or last node selected
                        if (((nodeFirst.X == node.X) && (nodeFirst.Y == node.Y)) ||
                           ((nodeLast.X == node.X) && (nodeLast.Y == node.Y)))
                        {
                            // First node selected
                            if ((nodeFirst.X == node.X) && (nodeFirst.Y == node.Y))
                            {
                                isFirst = true;
                            }

                            nodeSelectedFirst.X = node.X;
                            nodeSelectedFirst.Y = node.Y;

                            msg = "VALID_START_NODE";
                            headingMsg = TogglePlayer(false);
                            responseMsg = "Select a second node to complete the line.";
                            response.Add("newLine", null);
                            isNodeOne = true;

                            if (!connectRulesStack.Contains(node))
                            {
                                connectRulesStack.Push(node);
                            }
                        }
                        else
                        {
                            msg = "INVALID_START_NODE";
                            headingMsg = TogglePlayer(false);
                            response.Add("newLine", null);
                            responseMsg = "Not a valid starting position. Try Again";
                        }
                    }
                }
                else
                {
                    msg = "INVALID_END_NODE";
                    headingMsg = TogglePlayer(false);
                    response.Add("newLine", null);
                    responseMsg = "Invalid move. Try Again!";
                    isNodeOne = false;
                }
            }
            // Initial response
            else
            {
                msg = "INITIALIZE";
                headingMsg = "Player 1";
                response.Add("newLine", null);
                response.Add("heading", headingMsg);

                response.Add("message", "Awaiting Player 1's move");

                // Reset game
                isNodeOne = false;
                connectRulesStack.Clear();
                connectSegmentsList.Clear();
                nodeFirst = new Point();
                nodeLast = new Point();

                return response;
            }

            // Set heading and body for server response
            response.Add("heading", headingMsg);
            response.Add("message", responseMsg);

            return response;
        }

        // Method to toggle player Message to client
        private string TogglePlayer(bool toggle)
        {
            string playerStr;

            if (toggle)
            {
                if (headingMsg.Contains("1"))
                {
                    playerStr = "Player 2";
                }
                else
                {
                    playerStr = "Player 1";
                }
            }
            else
            {
                playerStr = headingMsg;
            }

            return playerStr;
        }

        // This method will check to see if there are any valid
        // paths from the Start/End node selected
        private bool CheckWinner(Point node)
        {
            int x = 0;
            int y = 0;

            int xMax = node.X;
            int yMax = node.Y;

            if (node.X != 0 && node.X <= MAX_X)
            {
                x = node.X - 1;
            }
            if (node.Y != 0 && node.Y <= MAX_Y)
            {
                y = node.Y - 1;
            }
            if (node.X < MAX_X)
            {
                xMax = node.X + 1;
            }
            if (node.Y < MAX_Y)
            {
                yMax = node.Y + 1;
            }

            for (int i = x; i <= xMax; i++)
            {
                for (int j = y; j <= yMax; j++)
                {
                    Point point = new Point(i, j);

                    // This is the node being checked, so skip
                    if (node == point)
                        continue;
                    if (!connectRulesStack.Contains(point))
                    {
                        // Check for crossing line segments
                        foreach (ConnectSegment connectSegment in connectSegmentsList)
                        {
                            if (LineIntersection(connectSegment, new ConnectSegment(point, node)))
                            {
                                return false;
                            }
                        }
                        return false;
                    }
                }
            }

            return true;
        }

        // Will check to see if the line is valid
        private bool AddLine(Point node)
        {
            int pushCount = 0;
            bool isValid = true;

            // Check if line ended on first or last node
            if (((nodeFirst.X == node.X) && (nodeFirst.Y == node.Y)) ||
                           ((nodeLast.X == node.X) && (nodeLast.Y == node.Y)))
            {
                return false;
            }

            // Check for crossing line segments
            foreach (ConnectSegment connectSegment in connectSegmentsList)
            {
                if (LineIntersection(connectSegment, new ConnectSegment(nodeSelectedFirst, nodeSelectedLast)))
                {
                    return false;
                }
            }

            bool isFirstLast = false;
            // Vertical line
            if (nodeSelectedFirst.X == node.X)
            {
                int yStart, yEnd;

                if (nodeSelectedFirst.Y >= node.Y)
                {
                    yEnd = nodeSelectedFirst.Y;
                    yStart = node.Y;
                }
                else
                {
                    yStart = nodeSelectedFirst.Y;
                    yEnd = node.Y;
                }

                for (int i = yStart; i <= yEnd; i++)
                {
                    Point point = new Point(node.X, i);

                    if (connectRulesStack.Contains(point) &&
                        (point.X != nodeSelectedFirst.X) && (point.Y != nodeSelectedFirst.Y))
                    {
                        // Remove nodes from stack if added because invalid move
                        for (int j = 0; j < pushCount; j++)
                        {
                            connectRulesStack.Pop();
                        }
                        return false;
                    }
                    else
                    {
                        isValid = false;
                        if (!connectRulesStack.Contains(point))
                        {
                            connectRulesStack.Push(point);
                            pushCount++;
                            isValid = true;
                        }
                        else if (connectRulesStack.Contains(point))
                        {
                            if (isFirstLast)
                            {
                                return false;
                            }
                            else
                            {
                                if ((nodeSelectedFirst.X == node.X && nodeSelectedFirst.Y == node.Y) ||
                                   (nodeSelectedLast.X == node.X && nodeSelectedLast.Y == node.Y))
                                {
                                    isValid = true;
                                    isFirstLast = true;
                                }
                            }
                        }
                    }
                }
            }
            // Horizontal line
            else if (nodeSelectedFirst.Y == node.Y)
            {
                int xStart, xEnd;

                if (nodeSelectedFirst.X >= node.X)
                {
                    xEnd = nodeSelectedFirst.X;
                    xStart = node.X;
                }
                else
                {
                    xStart = nodeSelectedFirst.X;
                    xEnd = node.X;
                }

                for (int i = xStart; i <= xEnd; i++)
                {
                    Point point = new Point(i, node.Y);

                    if (connectRulesStack.Contains(point) &&
                        (point.X != nodeSelectedFirst.X) && (point.Y != nodeSelectedFirst.Y))
                    {
                        // Remove nodes from stack if added because invalid move
                        for (int j = 0; j < pushCount; j++)
                        {
                            connectRulesStack.Pop();
                        }
                        return false;
                    }
                    else
                    {
                        isValid = false;
                        if (!connectRulesStack.Contains(point))
                        {
                            connectRulesStack.Push(point);
                            pushCount++;
                            isValid = true;
                        }
                        else if (connectRulesStack.Contains(point))
                        {
                            if (isFirstLast)
                            {
                                return false;
                            }
                            else
                            {
                                if ((nodeSelectedFirst.X == node.X && nodeSelectedFirst.Y == node.Y) ||
                                   (nodeSelectedLast.X == node.X && nodeSelectedLast.Y == node.Y))
                                {
                                    isValid = true;
                                    isFirstLast = true;
                                }
                            }
                        }
                    }
                }
            }
            // Diagonal line
            else
            {
                // Check slope, must be 45 degrees
                float m = (float)(nodeSelectedFirst.Y - node.Y) / (nodeSelectedFirst.X - node.X);
                int xStart, xEnd;
                int yStart, yEnd;
                if (Math.Abs(m) != 1f)
                    return false;

                if (m > 0.0)
                {

                    if (nodeSelectedFirst.Y >= node.Y)
                    {
                        yEnd = nodeSelectedFirst.Y;
                        yStart = node.Y;
                        xEnd = nodeSelectedFirst.X;
                        xStart = node.X;
                    }
                    else
                    {
                        yEnd = node.Y;
                        yStart = nodeSelectedFirst.Y;
                        xEnd = node.X;
                        xStart = nodeSelectedFirst.X;
                    }
                }
                else
                {
                    if (nodeSelectedFirst.Y <= node.Y)
                    {
                        yEnd = nodeSelectedFirst.Y;
                        yStart = node.Y;
                        xEnd = nodeSelectedFirst.X;
                        xStart = node.X;
                    }
                    else
                    {
                        yEnd = node.Y;
                        yStart = nodeSelectedFirst.Y;
                        xEnd = node.X;
                        xStart = nodeSelectedFirst.X;
                    }
                }

                for (int i = xStart; i <= xEnd; i++)
                {
                    Point point;
                    if (m > 0.0)
                    {
                        point = new Point(i, yStart++);
                    }
                    else
                    {
                        point = new Point(i, yStart--);
                    }

                    if (connectRulesStack.Contains(point) &&
                        (point.X != nodeSelectedFirst.X) && (point.Y != nodeSelectedFirst.Y))
                    {
                        // Remove nodes from stack if added because invalid move
                        for (int j = 0; j < pushCount; j++)
                        {
                            connectRulesStack.Pop();
                        }
                        return false;
                    }
                    else
                    {
                        isValid = false;
                        if (!connectRulesStack.Contains(point))
                        {
                            connectRulesStack.Push(point);
                            pushCount++;
                            isValid = true;
                        }
                        else if (connectRulesStack.Contains(point))
                        {
                            if (isFirstLast)
                            {
                                return false;
                            }
                            else
                            {
                                if ((nodeSelectedFirst.X == node.X && nodeSelectedFirst.Y == node.Y) ||
                                   (nodeSelectedLast.X == node.X && nodeSelectedLast.Y == node.Y))
                                {
                                    isValid = true;
                                    isFirstLast = true;
                                }
                            }
                        }
                    }
                }
            }
            return isValid;
        }

        // Helper method to determine if two line segments intersect on the 
        // gameboard
        private bool LineIntersection(ConnectSegment A, ConnectSegment B)
        {
            // Line A represented as a1x + b1y = c1
            double a1 = A.pointB.Y - A.pointA.Y;
            double b1 = A.pointA.X - A.pointB.X;
            double c1 = a1 * (A.pointA.X) + b1 * (A.pointA.Y);

            // Line B represented as a2x + b2y = c2
            double a2 = B.pointB.Y - B.pointA.Y;
            double b2 = B.pointA.X - B.pointB.X;
            double c2 = a2 * (B.pointA.X) + b2 * (B.pointA.Y);

            double determinant = a1 * b2 - a2 * b1;

            if (determinant == 0)
            {
                // The lines are parallel. 
                return false;
            }
            else
            {
                double x = (b2 * c1 - b1 * c2) / determinant;
                double y = (a1 * c2 - a2 * c1) / determinant;

                // Lines intersect within grid
                if ((x >= 0.0 && x <= 3.0) == true && (y >= 0.0 && y <= 3.0) == true)
                {
                    // Check if starting point is first or last
                    if (nodeSelectedFirst.X != nodeFirst.X && nodeSelectedFirst.Y != nodeFirst.Y &&
                        nodeSelectedFirst.X != nodeLast.X && nodeSelectedFirst.Y != nodeFirst.Y)
                    {
                        return true;
                    }
                }
                if (connectRulesStack.Contains(nodeSelectedLast))
                {
                    return true;
                }
                else
                {
                    int xAstart, xAend;
                    if (B.pointA.X >= B.pointB.X)
                    {
                        xAend = B.pointA.X;
                        xAstart = B.pointB.X;
                    }
                    else
                    {
                        xAend = B.pointB.X;
                        xAstart = B.pointA.X;
                    }

                    if ((x > xAstart && x < xAend) == true)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    // Class which represents a segment
    public class ConnectSegment
    {
        public Point pointA;
        public Point pointB;
        public ConnectSegment(Point pointA, Point pointB)
        {
            this.pointA = pointA;
            this.pointB = pointB;
        }
    }
}
